#include<stdint.h>
#include<stdbool.h>
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/adc.h"
#include "driverlib/pwm.h"
#include "driverlib/uart.h"
#include "driverlib/gpio.h"
#include "driverlib/debug.h"
#include "driverlib/timer.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "uartstdio.h"

uint32_t pwm0_gen0_load, pw, timerA_cnt, timerB_cnt, cm, int_cm, de_cm;
unsigned int cnt, x, y, i;
volatile int data, time;
unsigned long ulPeriod;
double dutyratio = 0.5;
bool timeron;

//Ultra Sensor & Buzzer Interrupt
void Int_Timer2A(){
    TimerIntClear(TIMER2_BASE, TIMER_TIMA_TIMEOUT);
    if(timerA_cnt == 0) GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, GPIO_PIN_2);
    if(timerA_cnt == 1) GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, 0);
    timerA_cnt++;
    if(timerA_cnt > 150) timerA_cnt = 0;
}

void Int_Timer2B(){
    TimerIntClear(TIMER2_BASE, TIMER_TIMB_TIMEOUT);
    timerB_cnt++;
}

void Int_GPIOB(){
    GPIOIntClear(GPIO_PORTB_BASE, GPIO_PIN_3);
    if(GPIOPinRead(GPIO_PORTB_BASE, GPIO_PIN_3) == GPIO_PIN_3){
        timerB_cnt = 0;
        TimerEnable(TIMER2_BASE, TIMER_B);
    }
    if(GPIOPinRead(GPIO_PORTB_BASE, GPIO_PIN_3) == 0){
        TimerDisable(TIMER2_BASE, TIMER_B);
        cm = timerB_cnt * 17.0 / 100.0;
        int_cm = (int)cm;
        de_cm = (int)(cm * 100) % 100;
        if(int_cm <= 4) {
            while(cnt < 50){
                GPIOPinWrite(GPIO_PORTB_BASE, 0x20, 0x20);
                for(i = 0; i < 1000; i++);

                GPIOPinWrite(GPIO_PORTB_BASE, 0x20, 0x00);
                for(i = 0; i < 10000; i++);
                cnt++;
            } cnt = 0;
            if(cnt == 0) GPIOPinWrite(GPIO_PORTB_BASE, 0x20, 0x00);
        }
    }
}

//Timer Function Interrupt
void Int_Timer1(){
    TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
    if(pw) {
        if(time == 0) {
            TimerDisable(TIMER1_BASE,TIMER_A);
            TimerDisable(TIMER2_BASE,TIMER_A);
            TimerDisable(TIMER2_BASE,TIMER_B);
            GPIOIntDisable(GPIO_PORTB_BASE, GPIO_PIN_3);
            PWMOutputState(PWM0_BASE, PWM_OUT_6_BIT, false);
            GPIOPinWrite(GPIO_PORTF_BASE, 0x02, 0x02);
            for(i = 0; i < 20000; i++);

            GPIOPinWrite(GPIO_PORTF_BASE, 0x02, 0x00);
            for(i = 0; i < 1000000; i++);
        } else if(time >= 0) {
            PWMOutputState(PWM0_BASE, PWM_OUT_6_BIT, true);
            time--;
            if(time == 0 && data < 2) pw = 0;
        }
    }
}

//Timer +- & Speed Control Function Interrupt
void Int_Timer0(){
    TimerIntClear(TIMER0_BASE,TIMER_TIMA_TIMEOUT);
    data = UARTCharGetNonBlocking(UART1_BASE);
    if(data == -1) {
        pw = 0;
        TimerDisable(TIMER1_BASE,TIMER_A);
        TimerDisable(TIMER2_BASE,TIMER_A);
        TimerDisable(TIMER2_BASE,TIMER_B);
        GPIOIntDisable(GPIO_PORTB_BASE, GPIO_PIN_3);
        PWMOutputState(PWM0_BASE, PWM_OUT_6_BIT, false);
    } else if (data == 0) {
        PWMOutputState(PWM0_BASE, PWM_OUT_6_BIT, false);
        dutyratio = 0.7;
        PWMPulseWidthSet(PWM0_BASE, PWM_OUT_6_BIT, pwm0_gen0_load * dutyratio);
        PWMOutputState(PWM0_BASE, PWM_OUT_6_BIT, true);
    } else if (data > 1 && data < 7) {
        pw = 1;
        TimerEnable(TIMER2_BASE, TIMER_A);
        TimerEnable(TIMER2_BASE, TIMER_B);
        GPIOIntEnable(GPIO_PORTB_BASE, GPIO_PIN_3);
        if(data > 2){
            GPIOPinWrite(GPIO_PORTF_BASE, 0x0E, 0x04);
            for(ulPeriod = 0; ulPeriod < 200000; ulPeriod++);

            GPIOPinWrite(GPIO_PORTF_BASE, 0x0E, 0x00);
            for(ulPeriod = 0; ulPeriod < 200000; ulPeriod++);
        }
        if(data == 3 || data == 4) { // Running Time Control
            if(data == 3) {
                time -= 10;
                if(time < 0) {
                    time = 0; TimerDisable(TIMER1_BASE, TIMER_A);
                }
            } else if (data == 4){
                time += 10;
                if(time > 30){
                    time = 30; TimerEnable(TIMER1_BASE, TIMER_A);
                }
            }
            TimerEnable(TIMER1_BASE, TIMER_A);

        } else if(data == 5 || data == 6) { // Fan Speed Decrease
            if(data == 5) {
                dutyratio -= 0.2;
                if(dutyratio < 0.5) {
                    dutyratio = 0.5;
                }
                PWMOutputState(PWM0_BASE, PWM_OUT_6_BIT, false);
                PWMPulseWidthSet(PWM0_BASE, PWM_OUT_6, pwm0_gen0_load * dutyratio);
                PWMOutputState(PWM0_BASE, PWM_OUT_6_BIT, true);
            } else if (data == 6){
                dutyratio += 0.2;
                if(dutyratio > 0.9){
                    dutyratio = 0.9;
                }
                PWMOutputState(PWM0_BASE, PWM_OUT_6_BIT, false);
                PWMPulseWidthSet(PWM0_BASE, PWM_OUT_6, pwm0_gen0_load * dutyratio);
                PWMOutputState(PWM0_BASE, PWM_OUT_6_BIT, true);
            }
        }
    }
}


void ConfigurePWM0(){
    PWMGenConfigure(PWM0_BASE, PWM_GEN_3, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC);
    pwm0_gen0_load = SysCtlClockGet() / 1000;
    PWMGenPeriodSet(PWM0_BASE, PWM_GEN_3, pwm0_gen0_load);
    PWMPulseWidthSet(PWM0_BASE, PWM_OUT_6, pwm0_gen0_load * dutyratio);
    PWMGenEnable(PWM0_BASE, PWM_GEN_3);
    PWMOutputState(PWM0_BASE, PWM_OUT_6_BIT, false);
}

void ConfigureUart1() {
    UARTConfigSetExpClk(UART1_BASE, SysCtlClockGet(), 57600, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
}

void ConfigureGPIO(){
    SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF));

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOB));

    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART1);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_UART1));

    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER0));

    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER1));

    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER2);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER2));

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOD));

    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_PWM0));

    GPIOPinTypeUART(GPIO_PORTB_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    GPIOPinConfigure(GPIO_PB0_U1RX);
    GPIOPinConfigure(GPIO_PB1_U1TX);
    GPIOPinTypePWM(GPIO_PORTD_BASE, GPIO_PIN_0);
    GPIOPinConfigure(GPIO_PD0_M0PWM6);
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, 0x0E);
    GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_2 | GPIO_PIN_4 | GPIO_PIN_5);
    GPIODirModeSet(GPIO_PORTB_BASE, GPIO_PIN_3, GPIO_DIR_MODE_IN);
    GPIOPadConfigSet(GPIO_PORTB_BASE, GPIO_PIN_3, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD);

    IntMasterEnable();

    GPIOPinWrite(GPIO_PORTD_BASE, GPIO_PIN_4, GPIO_PIN_4);

    GPIOIntTypeSet(GPIO_PORTB_BASE, GPIO_PIN_3, GPIO_BOTH_EDGES);

    IntEnable(INT_GPIOB);
    GPIOIntEnable(GPIO_PORTB_BASE, GPIO_PIN_3);
}

void ConfigureTimer(){
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
    TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);
    TimerConfigure(TIMER2_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_A_PERIODIC | TIMER_CFG_B_PERIODIC);
    TimerLoadSet(TIMER0_BASE, TIMER_A, SysCtlClockGet() / 4);
    TimerLoadSet(TIMER1_BASE, TIMER_A, SysCtlClockGet());
    TimerLoadSet(TIMER2_BASE, TIMER_BOTH, SysCtlClockGet() / 200000 * 3);
    IntEnable(INT_TIMER0A);
    IntEnable(INT_TIMER1A);
    IntEnable(INT_TIMER2A);
    IntEnable(INT_TIMER2B);
    TimerIntEnable(TIMER0_BASE,TIMER_TIMA_TIMEOUT);
    TimerIntEnable(TIMER1_BASE,TIMER_TIMA_TIMEOUT);
    TimerIntEnable(TIMER2_BASE,TIMER_TIMA_TIMEOUT | TIMER_TIMB_TIMEOUT);
    TimerEnable(TIMER0_BASE,TIMER_A);
    TimerDisable(TIMER1_BASE,TIMER_A);
    TimerEnable(TIMER2_BASE,TIMER_A);
}

int main(void) {
    time = 0;
    timerA_cnt = 0;

    ConfigureGPIO();
    ConfigureUart1();
    ConfigurePWM0();
    ConfigureTimer();

    while(1) ;
}
